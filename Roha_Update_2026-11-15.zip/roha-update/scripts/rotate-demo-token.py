"""Rotate the one shared Roha test token. Run after a teammate test, then restart."""
from pathlib import Path
from dotenv import set_key
import os
import secrets

root = Path(__file__).resolve().parent.parent
path = root / '.env'
if not path.is_file():
    raise SystemExit('Expected the existing repository .env file. No settings were changed.')
set_key(path, 'ROHA_API_TOKEN', secrets.token_urlsafe(32))
os.chmod(path, 0o600)
print('Roha demo token rotated in .env. Restart the API for the change to take effect.')
print('The token was not printed. Only share it privately with a trusted teammate for testing.')
