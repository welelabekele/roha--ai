"""Test a teammate's running Roha API without placing a token in browser code."""
import argparse
import getpass
import json
import os
import urllib.error
import urllib.parse
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward a bearer token to a GitHub login or another origin.
        return None


def make_request(url, token, language, field, message):
    parsed = urllib.parse.urlsplit(url)
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Use the plain forwarded base URL without credentials, query parameters, or fragments.')
    local = parsed.hostname in ('localhost', '127.0.0.1')
    if parsed.scheme != 'https' and not (local and parsed.scheme == 'http'):
        raise ValueError('Use an HTTPS forwarded URL, or HTTP on localhost for a local test.')
    body = json.dumps({'task': 'registration', 'language': language, 'field': field,
                       'message': message}, ensure_ascii=False).encode('utf-8')
    return urllib.request.Request(url.rstrip('/') + '/v1/turn', data=body,
                                  headers={'Authorization': 'Bearer ' + token,
                                           'Content-Type': 'application/json'}, method='POST')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default=os.getenv('ROHA_API_URL'))
    parser.add_argument('--language', default='en', choices=['en', 'am', 'om', 'ti'])
    parser.add_argument('--field', default='idRoute', choices=['name', 'phone', 'idRoute'])
    parser.add_argument('--message', default='I do not have an identity document. What are my options?')
    args = parser.parse_args()
    if not args.url:
        parser.error('Pass --url or set ROHA_API_URL to your teammate\'s forwarded port-8000 URL.')
    token = os.getenv('ROHA_API_TOKEN') or getpass.getpass('Roha demo token (hidden): ')
    if len(token) < 32:
        raise SystemExit('Enter the full Roha demo token, not a GitHub token.')
    try:
        request = make_request(args.url, token, args.language, args.field, args.message)
        with urllib.request.build_opener(NoRedirect).open(request, timeout=210) as response:
            result = json.load(response)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except ValueError as error:
        raise SystemExit(str(error))
    except urllib.error.HTTPError as error:
        if error.code in (301, 302, 303, 307, 308):
            raise SystemExit('The server redirected the request. Check that port 8000 is Public and use its actual forwarded URL. The token was not forwarded.')
        raise SystemExit(f'HTTP {error.code}. Check the forwarded URL, Roha token, and server status. No token is printed.')
    except urllib.error.URLError:
        raise SystemExit('Could not reach Roha. Check that the Codespace and API are running.')
    except TimeoutError:
        raise SystemExit('Roha did not reply in time. Check the server terminal; local commands still work without this API.')


if __name__ == '__main__':
    main()
