# Verification of this update

## Browser behavior: 19 checks passed

The bundled page was executed in real headless Chromium. The tests exercised:

1. Computed text size increased by 25% with zero API requests; an element outside Roha retained its font size.
2. Common English size phrases, addressing Roha, and the reported `lager` typo worked locally.
3. A negative size request did not enlarge text or call the model.
4. Simple wording changed while existing answers stayed intact.
5. Local size and simple-mode controls worked with the browser offline.
6. High contrast changed only the Roha root.
7. A proposed answer stayed unapplied until learner confirmation and did not submit an application.
8. UI controls remained responsive during delayed inference; stale responses could not overwrite a newer local command.
9. Model-provided HTML was displayed as text; unknown actions did not execute.
10. A selected file required consent and confirmation; no API upload happened.
11. Disallowed file extensions and files over 10 MB were rejected by the local attachment UI.
12. Folder access began only after activation, requested read-only mode, stopped at 50 immediate entries, and did not traverse subfolders.
13. Only the explicitly chosen folder file's File object was obtained, with no calls to read its contents.
14. Forget cleared references and prevented a delayed file request from restoring a forgotten selection.
15. Denied folder permission exposed no listing.
16. A browser without the directory-picker API retained normal file selection.
17. The interface reflowed at 200% component text size in a 320px viewport without document horizontal overflow.
18. Ctrl+Enter executed the local command.
19. The token and answers were not written to localStorage or sessionStorage.

Model replies and directory handles/permission responses were mocked to test application behavior. Browser-native File objects and file-input events were used. These tests do not establish actual OS permission-dialog accessibility, full browser zoom, microphone capture, native-speaker speech accuracy, screen-reader usability, or WCAG conformance. Native OS directory permission prompts must still be tested by a person. A component text-size reflow check is not a substitute for the hackathon's actual browser-zoom gate.

## Installer and teammate tools

Temporary-repository checks passed for installer backups, preserving app.py/.env/active speech worker, safe repeat installation, and rejecting a changed package file before applying it. Token rotation changed only the shared token, preserved unrelated settings, and did not print the new token. The friend API client rejected unsafe URL formats and refused an HTTP redirect, with no bearer credential forwarded to the redirect destination.

The optional ONNX files are the prior tested alternative: actual English reference transcription succeeded through Roha's API in the preparation environment. No claim is made that it has been installed or validated on your Codespace. All model weights remain separate downloads.

## Reproduce browser checks

From the extracted ZIP directory, install Playwright as a development/test dependency, install its Chromium browser, then run:

```bash
npm install --no-save playwright
npx playwright install chromium
node verification/ui-actions.cjs
```

If using an existing compatible Chrome headless-shell binary, set `ROHA_CHROMIUM` to its executable path. Tests start their own local HTTP server; an actual model/backend is not needed. Runtime Roha does not depend on Node, Playwright, or the browser-test packages.
