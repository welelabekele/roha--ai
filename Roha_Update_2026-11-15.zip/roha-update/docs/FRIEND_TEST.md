# Share your running Roha backend with a trusted teammate

## Browser test

1. Start `bash scripts/start.sh` in the Codespace and leave its terminal running. Ctrl+C shuts down the API.
2. Open the **Ports** panel. Change **8000 → Port Visibility → Public** for the demo. Keep port **11434 private**.
3. Copy port 8000's actual **forwarded URL**, not the editor URL or the GitHub repository URL. It resembles `https://YOUR-CODESPACE-NAME-8000.app.github.dev`.
4. Ask your friend to open that URL plus `/health`. It should return the running-status JSON. This endpoint does not prove model quality/readiness.
5. Your friend can open the main page. Local size/simple-mode commands work without a token when the page is loaded.
6. For AI and transcription, your current API uses one shared `ROHA_API_TOKEN`, not per-user accounts or automatic expiration. For a short trusted-developer test, share that Roha test token privately. Never share GitHub tokens or passwords.
7. The token can be viewed in your private terminal with:

```bash
.venv/bin/python -c 'from dotenv import dotenv_values; print(dotenv_values(".env")["ROHA_API_TOKEN"])'
```

Do not paste it into public code, a public issue, or this chat. Your friend enters it under **Connect the AI and transcription server** in the private developer test UI. Public port visibility makes the page reachable; Roha's `/v1` routes still check the bearer token.

## Your friend is building a separate frontend

The friend's backend should call the Codespaces API. Keep `ROHA_API_TOKEN` in that backend's environment, outside browser JavaScript. Protect their proxy with their own learner authentication/authorization and quotas; simply hiding a secret behind an unauthenticated proxy is not access control.

For a direct developer test, give your friend `scripts/friend_client.py`. It uses only Python's standard library and prompts for the token without echoing it:

```bash
python3 scripts/friend_client.py --url https://YOUR-CODESPACE-NAME-8000.app.github.dev
```

Or test a fictional answer:

```bash
python3 scripts/friend_client.py --url https://YOUR-CODESPACE-NAME-8000.app.github.dev --field name --message "My name is Sara."
```

The client refuses to forward the token through HTTP redirects. A redirect usually means the port is private or the URL is wrong. It does not publish a port, expose Ollama, or give access to files on your computer.

API endpoints:

- `GET /health`: running process check, unauthenticated.
- `GET /v1/status`: model configuration/presence, token required.
- `POST /v1/turn`: text request, token required; returns a proposal.
- `POST /v1/transcribe`: audio plus explicit consent, token required and speech must be enabled.

Server-to-server calls do not need browser CORS changes. If you later deliberately support cross-origin browser requests, use exact permitted origins and real user authentication; do not put the shared server token into the public plugin. Origins are not an authentication mechanism.

## After testing

Make port 8000 private again when public testing is over. Rotate the shared test token if it was distributed:

```bash
.venv/bin/python scripts/rotate-demo-token.py
```

Restart the API for the new token to take effect. Existing tests using the old token will then fail authentication. Rotation is manual; this helper does not create per-user or expiring accounts. If ROHA_API_TOKEN was also exported in your shell or a service environment, update/remove that override before restarting; it can override the .env file.

Codespaces stops after inactivity and after a maximum running session lifetime. Restart the Codespace/API and check port visibility when necessary. This is a hackathon demo host, not a permanent production deployment.

Official references:
- https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace
- https://docs.github.com/en/codespaces/about-codespaces/understanding-the-codespace-lifecycle
