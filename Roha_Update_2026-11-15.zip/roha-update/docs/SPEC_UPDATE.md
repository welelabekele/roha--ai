# Scope of the 2026-11-15 update

The existing API is preserved. UI actions now execute within Roha's own root without an inference request. Models propose form answers; the learner confirms them. Only server-approved field/value combinations are accepted for a proposal, and no submission occurs in this demo.

## Attachment permission states

No selection → native file choice OR user-activated read-only folder picker → display selected metadata → learner chooses attachment consent → learner confirms → in-memory draft attachment.

Forget or page exit drops current handles/references and invalidates pending file operations. It does not claim to revoke an origin permission stored by the browser. A denied/cancelled folder choice exposes no folder listing. No directory recursion, file-content preview, background scanning, write operation, model tool, or network upload is implemented.

The browser enforces access to selected local resources. The application adds a purpose-specific choice/confirmation flow, a maximum of 50 immediate folder entries, a 10 MB file size limit, a restricted document-extension list, and a file-picker fallback. These controls do not sandbox the component against scripts on the same trusted host origin. A future isolated iframe integration requires a separate audited host bridge.

Attachment objects and private support preferences must not be added to LLM prompts automatically. A future upload integration must validate actual contents server-side, use authorization and explicit upload consent, and never treat document selection as medical/status proof.

## Language and assistant boundaries

English display-command aliases are implemented. Amharic, Oromo and Tigrinya model request codes remain in the existing backend but their response quality is not validated. No wider language support is implied by displaying a language option. Voice transcription and installed speech synthesis are separate providers. No background wake-word engine or OS-wide file access is present.

## Deployment boundary

Codespaces hosts the existing demo API through forwarded port 8000. Raw Ollama stays on private port 11434. A shared test token is permitted for a short trusted-teammate test, with manual rotation afterward. Production needs appropriate learner authentication, per-user quotas, deployment uptime, and a backend integration that keeps provider/server credentials out of public JavaScript.
