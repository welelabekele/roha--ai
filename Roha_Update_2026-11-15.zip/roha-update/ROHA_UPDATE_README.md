# Roha update — 15 November 2026

One update for your existing `roha--ai` Codespace. You do not need to download the earlier frontend or ONNX fix ZIPs.

## Apply the update

Upload **Roha_Update_2026-11-15.zip** into `/workspaces/roha--ai`. Run:

```bash
cd /workspaces/roha--ai
.venv/bin/python -m zipfile -e Roha_Update_2026-11-15.zip .
.venv/bin/python apply_roha_update.py
```

Keep the existing API running and hard-refresh the page with Ctrl+Shift+R, or Cmd+Shift+R on Mac. If the API is stopped, run `bash scripts/start.sh` and leave that terminal running.

The installer checks package file hashes, backs up replaced files under `.runtime/before-update-*`, and installs the new page and helper scripts. It **does not change app.py, your token, model files, or the active speech environment**. It adds ignore rules for local backups/settings. It does not perform a git pull, hard reset, model download, or public-port change.

## What works in this update

- Text size, contrast, question navigation, and simple question wording run locally, including offline. They do not wait for the LLM or require a server token.
- Try `make text larger`, `increase font size`, `make text lager`, `use simple words`, `read the question`, or the buttons.
- A model answer is shown for review and only changes the current answer after confirmation. No application is submitted.
- A normal file picker accepts one PDF, DOCX, TXT, PNG, or JPEG, up to 10 MB. The page shows its name and requires explicit consent plus confirmation before attaching it to the **local demo draft**.
- Optional folder selection requests **read-only** access. It lists at most 50 entries in the chosen folder. Subfolders are displayed as names but are not traversed. Only clicking a particular file obtains that File object. File contents are not read.
- Forget clears selected files, draft attachment, folder handles, and folder listing from memory. It also invalidates pending file requests so they cannot restore a forgotten selection. Saved browser permissions must be revoked through browser site settings.
- If folder selection is unsupported, the normal file chooser remains available. Folder selection needs HTTPS/localhost and a supported browser. A voice/text request directs the learner to activate the native permission control; it cannot bypass browser permission dialogs.

Files and folder entries are not uploaded, sent to the model, or persisted. This update has **no attachment upload endpoint**. An actual partner application needs its own approved, authenticated upload integration, server validation, and separate upload consent. Extension/size checks here are usability checks, not a malware scanner or proof of file contents.

This page runs within the trusted host website's JavaScript environment. It is not an isolation boundary against malicious scripts on that same origin. Strict host isolation requires a separate-origin iframe and an audited, permission-limited bridge; that is not included here. The update does not scan the host page or alter elements outside Roha's root.

## Voice and AI

The existing record → transcribe → review → Do this flow is preserved. Actual speech recognition requires your speech backend. The local command aliases are English; additional language phrases need native-speaker review and tests. The language menu does not establish multilingual understanding. Qwen's Amharic/Tigrinya replies previously failed quality checks and remain experimental.

Simple mode uses supplied question wording; it does not rewrite arbitrary website content, legal statements, or learner answers. Read-aloud uses installed browser voices and announces when no matching voice exists. There is no always-on wake-word engine, OS-wide assistant, or arbitrary desktop file control.

## Optional lighter ONNX speech setup

Only do this if you still need the alternative speech runtime:

```bash
bash scripts/install-onnx-speech.sh
bash scripts/speech-smoke-onnx.sh .runtime/onnx-speech/reference-en.wav
```

The installer downloads an approximately 292 MB model archive once and uses a separate `.venv-onnx`. It checks the exact tested archive/model/tokenizer hashes. The model weights are not inside this small update ZIP. The speech runtime is not enabled automatically.

After a successful real recording test, stop the API with Ctrl+C, then run:

```bash
bash scripts/enable-onnx-speech.sh
bash scripts/start.sh
```

The activation script then deliberately changes the speech worker and speech settings, preserving a backup and the API token. The natural English reference was decoded successfully in the preparation environment. Synthetic local-language clips were misrecognized; native-speaker recordings are required to assess actual language accuracy.

## Let a friend test

Follow `docs/FRIEND_TEST.md`. Open port 8000 publicly for a controlled demo, keep 11434 private, and share only the Roha test credential privately with a trusted teammate. The included `scripts/friend_client.py` makes API requests without putting the token into frontend code. `scripts/rotate-demo-token.py` can rotate the shared credential after a test; restart the API afterward.

Codespaces is a temporary development host. The running service is not a permanent deployment. It can stop after inactivity and has a maximum 12-hour running session before restart. GitHub's included compute/storage allowance still applies. Do not disable timeouts with keep-alive tricks.

## Scope

This remains a command/answer and attachment-permission demo for the existing backend. It is not a complete Track 1 submission, universal website adapter, persistent learner account system, employer/job application product, or fully validated multilingual voice assistant. The form and assistive-technology gate still need real co-designer testing.

Package verification results and reproduction instructions are in `docs/VERIFICATION.md` and `verification/ui-actions.cjs` inside the ZIP. Source references: MDN's showDirectoryPicker and file-input documentation, GitHub's Codespaces port-forwarding/lifecycle documentation, and the official sherpa-onnx export/API examples linked in the optional ONNX notes.
