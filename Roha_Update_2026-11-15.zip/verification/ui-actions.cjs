/* Run against the new static page: ROHA_TEST_URL=http://127.0.0.1:8765 node tests/ui-actions.cjs */
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

(async () => {
  const server = http.createServer((request, response) => {
    response.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
    response.end(fs.readFileSync(path.join(__dirname, '../roha-update/index.html')));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({headless: true, ...(process.env.ROHA_CHROMIUM ? {executablePath: process.env.ROHA_CHROMIUM} : {})});
  const context = await browser.newContext({viewport: {width: 1000, height: 1000}});
  const page = await context.newPage();
  let calls = 0;
  let behavior = 'proposal';
  page.on('request', request => {if (new URL(request.url()).pathname === '/v1/turn') calls++;});
  await page.route('**/v1/turn', async route => {
    const body = route.request().postDataJSON();
    assert.equal(Object.hasOwn(body, 'token'), false);
    assert.equal(Object.hasOwn(body, 'answers'), false);
    if (behavior === 'slow') await delay(900);
    const data = behavior === 'unsafe'
      ? {action: 'execute_javascript', reply: '<img src=x onerror=alert(1)>', value: 'run', source: 'ollama', executed: false}
      : {action: 'propose_answer', reply: 'Would you like to ask a partner for help?', value: 'partner_referral', field: 'idRoute', requires_confirmation: true, executed: false, source: 'ollama', reply_language: 'en'};
    try {await route.fulfill({status: 200, contentType: 'application/json', body: JSON.stringify(data)});} catch {}
  });
  await page.goto(process.env.ROHA_TEST_URL || 'http://127.0.0.1:' + server.address().port);
  const font = () => page.locator('#roha-root').evaluate(el => parseFloat(getComputedStyle(el).fontSize));
  const result = async () => JSON.parse(await page.locator('#output').textContent());
  const command = async text => {await page.locator('#message').fill(text);await page.locator('#ask').click();};
  const passed = [];
  const pass = name => {passed.push(name);console.log('PASS', name);};

  const original = await font();
  await page.evaluate(() => {const outside = document.createElement('p');outside.id = 'host-sentinel';outside.textContent = 'Host content';document.body.append(outside);});
  const hostFont = await page.locator('#host-sentinel').evaluate(el => getComputedStyle(el).fontSize);
  await command('make text larger');
  assert.ok(Math.abs(await font() / original - 1.25) < .02);
  assert.equal((await result()).executed, true);
  assert.equal((await result()).source, 'local_command');
  assert.equal(calls, 0);
  assert.equal(await page.locator('#host-sentinel').evaluate(el => getComputedStyle(el).fontSize), hostFont);
  pass('Text visibly enlarges without a token or server call; host text stays unchanged');

  for (const text of ['increase font size', 'make text lager', 'Hey Roha, make the text bigger please.']) {
    await page.locator('#reset-size').click();
    await command(text);
    assert.ok(await font() > original);
  }
  assert.equal(calls, 0);
  pass('Common wording, wake-name prefix, and the reported typo work locally');

  const beforeNegative = await font();
  await command("don't make the text larger");
  assert.equal(await font(), beforeNegative);
  assert.equal((await result()).executed, false);
  assert.equal(calls, 0);
  pass('Negative requests do not enlarge text or fall through to the model');

  await page.locator('#route-answer').selectOption('national_id');
  await page.locator('#field').selectOption('name');
  await page.locator('#text-answer').fill('Sara test');
  await command('make it simple');
  assert.equal(await page.locator('#question').textContent(), 'What is your name?');
  assert.equal(await page.locator('#text-answer').inputValue(), 'Sara test');
  assert.equal(await page.locator('#simple').getAttribute('aria-pressed'), 'true');
  await command('show original wording');
  assert.equal(await page.locator('#question').textContent(), 'What is your full name?');
  await page.locator('#field').selectOption('idRoute');
  assert.equal(await page.locator('#route-answer').inputValue(), 'national_id');
  pass('Simple mode updates question wording while preserving answers');

  await context.setOffline(true);
  const beforeOffline = await font();
  await command('make text larger');
  assert.ok(await font() > beforeOffline);
  await command('use simple words');
  assert.equal(await page.locator('#question').textContent(), 'Do you have an ID?');
  assert.equal(calls, 0);
  await context.setOffline(false);
  pass('Local size and simple-mode commands work while offline');

  await page.locator('#contrast').click();
  assert.equal(await page.locator('#roha-root').evaluate(el => getComputedStyle(el).backgroundColor), 'rgb(0, 0, 0)');
  await page.locator('#contrast').click();
  pass('High contrast applies inside the Roha root');

  await page.locator('#connection summary').click();
  await page.locator('#token').fill('developer-test-token-never-saved');
  await command('I would like help choosing a document route');
  await page.locator('#proposal-pane').waitFor({state: 'visible'});
  assert.equal(await page.locator('#route-answer').inputValue(), 'national_id');
  assert.equal((await result()).executed, false);
  await page.locator('#confirm').click();
  assert.equal(await page.locator('#route-answer').inputValue(), 'partner_referral');
  assert.equal((await result()).submitted, false);
  pass('Model answers require learner confirmation and do not submit anything');

  behavior = 'slow';
  await command('Please explain my options in more detail');
  await page.locator('#cancel-ai').waitFor({state: 'visible'});
  const beforeDuringAI = await font();
  await page.locator('#larger').click();
  assert.ok(await font() > beforeDuringAI);
  await delay(1100);
  assert.equal((await result()).source, 'local_command');
  assert.equal(await page.locator('#proposal-pane').isVisible(), false);
  pass('Controls stay responsive during inference; stale AI replies cannot replace newer commands');

  behavior = 'unsafe';
  await command('What can you help me with?');
  await page.waitForFunction(() => document.getElementById('reply').textContent.includes('<img'));
  assert.equal(await page.locator('#reply img').count(), 0);
  assert.equal(await page.locator('#proposal-pane').isVisible(), false);
  assert.equal(await page.locator('#route-answer').inputValue(), 'partner_referral');
  pass('Untrusted model HTML is displayed as text; unknown actions do not execute');

  const filesPage = await context.newPage();
  let fileNetworkCalls = 0;
  filesPage.on('request', request => {if (new URL(request.url()).pathname.startsWith('/v1/')) fileNetworkCalls++;});
  await filesPage.addInitScript(() => {
    const stats = window.__grantStats = {pickers: 0, getFiles: 0, contentReads: 0, subfolders: 0, modes: []};
    const file = new File(['test document bytes'], 'cv.pdf', {type: 'application/pdf'});
    for (const method of ['text', 'arrayBuffer', 'stream']) {
      Object.defineProperty(file, method, {value: () => {stats.contentReads++;throw Error('Contents must not be read');}});
    }
    const entry = {kind: 'file', getFile: async () => {stats.getFiles++;if(window.__delayFile)await new Promise(r=>setTimeout(r,150));return file;}};
    window.showDirectoryPicker = async options => {
      stats.pickers++;stats.modes.push(options.mode);
      return {name: 'Allowed folder', queryPermission: async options => {
        stats.modes.push(options.mode);return window.__denyFolder ? 'denied' : 'granted';
      }, entries: async function*() {
        yield ['cv.pdf', entry];
        yield ['Private subfolder', {kind:'directory', entries:()=>{stats.subfolders++;throw Error('No recursion');}}];
        for(let i=0;i<70;i++)yield ['document-'+i+'.txt', {kind:'file',getFile:()=>{throw Error('Only chosen file may be read');}}];
      }};
    };
  });
  await filesPage.goto('http://127.0.0.1:' + server.address().port);
  await filesPage.locator('#file-choice').setInputFiles({name:'learner-cv.pdf',mimeType:'application/pdf',buffer:Buffer.from('test bytes')});
  assert.ok((await filesPage.locator('#selected-file').textContent()).includes('learner-cv.pdf'));
  assert.equal(await filesPage.locator('#attached-file').textContent(),'No file attached.');
  assert.equal(await filesPage.locator('#attach-file').isDisabled(),true);
  await filesPage.locator('#attachment-consent').check();
  await filesPage.locator('#attach-file').click();
  assert.ok((await filesPage.locator('#attached-file').textContent()).includes('learner-cv.pdf'));
  assert.equal(fileNetworkCalls,0);
  pass('A selected file requires explicit consent and confirmation; no file is uploaded');

  await filesPage.locator('#file-choice').setInputFiles({name:'program.exe',mimeType:'application/octet-stream',buffer:Buffer.from('not a document')});
  assert.equal(await filesPage.locator('#attach-file').isDisabled(),true);
  assert.ok((await filesPage.locator('#files-notice').textContent()).includes('Choose a PDF'));
  await filesPage.locator('#file-choice').setInputFiles({name:'too-big.pdf',mimeType:'application/pdf',buffer:Buffer.alloc(10*1024*1024+1)});
  assert.ok((await filesPage.locator('#files-notice').textContent()).includes('10 MB'));
  pass('Disallowed file extensions and oversized documents cannot be attached');

  assert.equal(await filesPage.evaluate(()=>window.__grantStats.pickers),0);
  await filesPage.locator('#choose-folder').click();
  await filesPage.waitForFunction(()=>document.querySelectorAll('#folder-files li').length===50);
  const grant = await filesPage.evaluate(()=>window.__grantStats);
  assert.deepEqual(grant.modes,['read','read']);
  assert.equal(grant.getFiles,0);assert.equal(grant.contentReads,0);assert.equal(grant.subfolders,0);
  assert.ok((await filesPage.locator('#folder-name').textContent()).includes('Allowed folder'));
  pass('Folder access is requested only on activation, is read-only, bounded to 50 entries, and does not recurse');

  await filesPage.getByRole('button',{name:'Select cv.pdf',exact:true}).click();
  await filesPage.waitForFunction(()=>document.getElementById('selected-file').textContent.includes('cv.pdf'));
  assert.equal(await filesPage.evaluate(()=>window.__grantStats.getFiles),1);
  assert.equal(await filesPage.evaluate(()=>window.__grantStats.contentReads),0);
  assert.equal(await filesPage.locator('#attach-file').isDisabled(),true);
  await filesPage.locator('#attachment-consent').check();await filesPage.locator('#attach-file').click();
  assert.ok((await filesPage.locator('#attached-file').textContent()).includes('cv.pdf'));
  assert.equal(fileNetworkCalls,0);
  pass('Only the explicitly selected folder file is obtained, without reading its contents');

  await filesPage.evaluate(()=>{window.__delayFile=true;});
  await filesPage.getByRole('button',{name:'Select cv.pdf',exact:true}).click();
  await filesPage.locator('#forget-files').click();await delay(220);
  assert.equal(await filesPage.locator('#selected-file').textContent(),'No file selected.');
  assert.equal(await filesPage.locator('#attached-file').textContent(),'No file attached.');
  assert.equal(await filesPage.locator('#folder-files li').count(),0);
  assert.equal(await filesPage.locator('#attachment-consent').isDisabled(),true);
  pass('Forget clears file/folder references and prevents a pending file request from restoring access');

  await filesPage.evaluate(()=>{window.__denyFolder=true;});await filesPage.locator('#choose-folder').click();
  await filesPage.waitForFunction(()=>document.getElementById('files-notice').textContent.includes('not granted'));
  assert.equal(await filesPage.locator('#folder-files li').count(),0);
  pass('Denied folder permission exposes no entries');
  await filesPage.close();

  const unsupported = await context.newPage();
  await unsupported.addInitScript(()=>{window.showDirectoryPicker=undefined;});
  await unsupported.goto('http://127.0.0.1:' + server.address().port);
  assert.equal(await unsupported.locator('#choose-folder').isDisabled(),true);
  await unsupported.locator('#file-choice').setInputFiles({name:'fallback.txt',mimeType:'text/plain',buffer:Buffer.from('fallback')});
  assert.ok((await unsupported.locator('#selected-file').textContent()).includes('fallback.txt'));
  await unsupported.close();
  pass('Browsers without the folder API retain normal file selection');

  await page.locator('#reset-size').click();
  for (let i = 0; i < 4; i++) await page.locator('#larger').click();
  await page.setViewportSize({width: 320, height: 900});
  assert.equal(await page.locator('#size-status').textContent(), 'Text size: 200%');
  const widths = await page.evaluate(() => ({scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth}));
  assert.ok(widths.scroll <= widths.client + 1, JSON.stringify(widths));
  pass('The interface reflows at 200% component text size and a 320px viewport');

  await page.setViewportSize({width: 1000, height: 1000});
  await page.locator('#reset-size').click();
  await page.locator('#message').fill('make text larger');
  await page.locator('#message').press('Control+Enter');
  assert.ok(await font() > original);
  pass('The keyboard shortcut executes the local command');

  await page.reload();
  await page.locator('#connection summary').click();
  assert.equal(await page.locator('#token').inputValue(), '');
  assert.equal(await page.evaluate(() => localStorage.length + sessionStorage.length), 0);
  pass('Token and answers are not persisted in browser storage');

  await page.screenshot({path: process.env.ROHA_SCREENSHOT || path.join(require('node:os').tmpdir(), 'roha-latest-ui-check.png'), fullPage: true});
  console.log('Completed', passed.length, 'browser behavior checks.');
  await browser.close();
  await new Promise(resolve => server.close(resolve));
})().catch(error => {console.error(error);process.exit(1);});
