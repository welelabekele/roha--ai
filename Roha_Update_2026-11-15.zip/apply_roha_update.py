"""Apply this update to an existing Roha repository, preserving settings and backups."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil

root = Path.cwd()
payload = Path(__file__).resolve().parent / 'roha-update'
if not (root / 'app.py').is_file() or not (root / 'static' / 'index.html').is_file():
    raise SystemExit('Run this from /workspaces/roha--ai, where app.py and static/index.html exist.')
manifest_path = payload / 'manifest.json'
if not manifest_path.is_file():
    raise SystemExit('Extract the entire Roha_Update_2026-11-15.zip first.')
manifest = json.loads(manifest_path.read_text())
for entry in manifest:
    source_relative = Path(entry['source'])
    if source_relative.is_absolute() or '..' in source_relative.parts:
        raise SystemExit('Invalid package source.')
    source = payload / source_relative
    destination = Path(entry['destination'])
    if destination.is_absolute() or '..' in destination.parts:
        raise SystemExit('Invalid package destination.')
    if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != entry['sha256']:
        raise SystemExit('Package file is missing or altered: ' + entry['source'])
backup = root / '.runtime' / ('before-update-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
backup.mkdir(parents=True)
os.chmod(backup, 0o700)
changed = []
for entry in manifest:
    source, target = payload / entry['source'], root / entry['destination']
    if target.exists() and target.read_bytes() == source.read_bytes():
        continue
    if target.exists():
        old = backup / entry['destination']
        old.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, old)
    target.parent.mkdir(parents=True, exist_ok=True)
    staged = target.with_name(target.name + '.roha-update-tmp')
    shutil.copy2(source, staged)
    staged.replace(target)
    changed.append(entry['destination'])
ignore = root / '.gitignore'
content = ignore.read_text() if ignore.exists() else ''
updated = content
for pattern in ['.env', '.runtime/', '.venv-onnx/']:
    if pattern not in updated.splitlines():
        updated += '\n' + pattern + '\n'
if updated != content:
    if ignore.exists():
        shutil.copy2(ignore, backup / '.gitignore')
    ignore.write_text(updated)
    changed.append('.gitignore')
print('Updated: ' + (', '.join(changed) if changed else 'files already current'))
print('Existing-file backups: ' + str(backup))
print('app.py, .env, existing model files, and active speech settings were preserved.')
print('Keep the API running and hard-refresh the page with Ctrl+Shift+R or Cmd+Shift+R.')
print('ONNX speech is included but is not installed or enabled automatically. See ROHA_UPDATE_README.md.')
